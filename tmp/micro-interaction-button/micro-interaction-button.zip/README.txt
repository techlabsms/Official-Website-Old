A Pen created at CodePen.io. You can find this one at https://codepen.io/philhoyt/pen/VjzjjR.

 Was inspired by this UI http://codepen.io/chrisdothtml/pen/xbmddV
But found it to limiting in practical use.