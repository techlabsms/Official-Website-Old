//included Font Awesome through JS
//Update: You can now have multiple line button without it looking wonky!